import React from 'react'

const Register = () => {
  return (
    <div>
        register

    </div>
  )
}

export default Register
